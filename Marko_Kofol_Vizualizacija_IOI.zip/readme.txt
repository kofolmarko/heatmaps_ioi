Pri izbiri podatkov me je zanimalo gibanje igralcev nogometa skozi vsako minuto tekme.
Želel sem, da uporabnik lahko izbere tekmo ter si ogleda premikanje igralcev skozi tekmo.

Pri obdelavi in prikazu podatkov sem uporabil p5.js.

Uporabnik se najprej sreča s prikazom tekme, ki je bila predhodno naložena. Za izbiro druge tekme, naj uporabnik klikne "API"
zavihek, ki ga bo pripeljal do obrazca za zajem podatkov s spleta za izbrano nogometno tekmo.

V zavihku "Visualization" so prikazani podatki tekme, in sicer so to podatki o vseh igralcih na tekmi, njihovo ime, priimek,
številka, pozicija, datum rojstva, starost, ocena na tekmi in seveda heat map.

Za vsako ekipo se lahko vklopi heat map posebej, s sliderjem se nastavlja minuto tekme v kateri želimo prikazati heat map.
Prav tako lahko prikažemo heat map s tem da kliknemo na posameznega igralca. S ponovnim klikom na istega igralca zapremo
njegov heatmap.
Igralce lahko razporedimo po njihovi oceni (najnižja do najvišje in najvišja do najniže).

Skozi vizualizacijo sem opazil, da imajo nekateri igralci zelo razpršeno gibanje, ostali se pa držijo določenega dela igrišča.
Zanimivo bi bilo obdelati in primerjati tudi ostale podatke o nogometaših na tekmi.