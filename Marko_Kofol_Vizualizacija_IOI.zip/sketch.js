const apiKey = "a38f188b6bmsh17e7e1f83bfab13p1aeca1jsn555d1cec312d";
const teamId = 21895;

/* CANVAS SETUP */
const cWidth = 500;
const cHeight = 500;

/* GLOBAL VARIABLES */
let activeTab; // Setup for window resizing
let sofascore;
let matchData;
let dataUrl = "matchData.json";
let displayData = false;
let bgImage;
let fieldImage;
let fieldWidth;
let fieldHeight;
let fieldX;
let fieldY;
let variableSettings = {
	Home_Heatmap: false,
	Away_Heatmap: false,
	// Add more variables here with their initial values
};
let selectedPlayer;

/* HEATMAP RANGE */
const x0 = 0;
const x1 = 100;
const y0 = 0;
const y1 = 100;

function preload() {
	matchData = loadJSON(dataUrl);
	fieldImage = loadImage("football_field.png");
    customFont = loadFont("Poppins-Regular.ttf");
    bgImage = loadImage("background.jpg");
}

function setup() {
	if (matchData) {
		let title = "File ready:";
		text(title, cWidth / 2 - textWidth(title) / 2, 400);
		text(dataUrl, cWidth / 2 - textWidth(dataUrl) / 2, 420);

		const startBtn = createButton("Start");
		startBtn.position(cWidth / 2 - startBtn.size().width / 2, 450);
		startBtn.mousePressed(() => {
			createVisualizationTab();
		});
	}

	
	createVisualizationTab(); //! TEMPORARY REMOVE LATER
}

function windowResized() {
	createVisualizationTab();
}

function draw() {
	if (displayData) {
	}
}

function createPlayerSegment(team, sortOption) {
    let playerListContainer = createDiv();
    playerListContainer.id(`playerList_${team}`);
    playerListContainer.id(team);
    playerListContainer.style("max-height", `${fieldHeight}px`);
    playerListContainer.style("overflow-y", "auto");
    playerListContainer.style("padding", "10px");
    playerListContainer.style("width", `${(windowWidth - fieldWidth) / 2 - 20}px`);

    if (sortOption === 'ratingAsc') {
        matchData.homeTeam.players.sort((a, b) => a.statistics.rating - b.statistics.rating);
        matchData.awayTeam.players.sort((a, b) => a.statistics.rating - b.statistics.rating);
    } else if (sortOption === 'ratingDesc') {
        matchData.homeTeam.players.sort((a, b) => b.statistics.rating - a.statistics.rating);
        matchData.awayTeam.players.sort((a, b) => b.statistics.rating - a.statistics.rating);
    }
    

    if (team === 'home') {
        playerListContainer.position(0, fieldY);
        playerListContainer.style("text-overflow", "ellipsis")
        for (let player of matchData.homeTeam.players) {
            createPlayerCard(player, playerListContainer, matchData.homeTeam.playerColor);
        }
    } else if (team === 'away') {
        playerListContainer.position(fieldX + fieldWidth, fieldY);
        for (let player of matchData.awayTeam.players) {
            createPlayerCard(player, playerListContainer, matchData.awayTeam.playerColor);
        }
    }
}

const createPlayerCard = ((player, playerListContainer, colors) => {
    let playerCard = createDiv('');
    playerCard.parent(playerListContainer);
    playerCard.style('padding', '15px');  // Increase padding for a bit more space
    playerCard.style('margin', '10px 0');  // Adjust margin for better spacing
    playerCard.style('background-color', `rgba(${hexToRgb(colors.primary)}, 0.8)`);  // Set the background color to the team color with transparency
    playerCard.style('border-radius', '8px');
    playerCard.style('box-shadow', '0 4px 8px rgba(0, 0, 0, 0.1)');
    playerCard.style('display', 'flex');  // Use flex display for better alignment

    let playerInfo = createDiv('');
    playerInfo.parent(playerCard);
    playerInfo.style('color', colors.number);  // Set text color to the player number color
    playerInfo.style('flex-grow', '1');  // Allow playerInfo to grow to fill available space
    playerInfo.style('display', 'flex');  // Use flex display for better alignment
    playerInfo.style('flex-direction', 'column');  // Stack items vertically

    let playerNumAndName = createP(`${player.jerseyNumber} ${player.player.name}`);
    playerNumAndName.parent(playerInfo);
    playerNumAndName.style("font-family", "Poppins-Regular");
    playerNumAndName.style("font-size", "1em");  // Adjust font size
    playerNumAndName.style("margin", "0");  // Adjust margin for spacing
    playerNumAndName.style("color", `#${colors.number}`);

    let playerPosition = createP(`Position: ${player.player.position}`);
    playerPosition.parent(playerInfo);
    playerPosition.style("font-family", "Poppins-Regular");
    playerPosition.style("font-size", "12px");  // Adjust font size
    playerPosition.style("margin", "0");
    playerPosition.style("color", `#${colors.number}`);  // Set text color to the player number color

    let birthDate = new Date(player.player.dateOfBirthTimestamp * 1000);
    let year = birthDate.getFullYear();
    let month = birthDate.getMonth() + 1; // Months are zero-based, so add 1
    let day = birthDate.getDate();
    let currentDate = new Date();
    let age = currentDate.getFullYear() - birthDate.getFullYear();
    if (currentDate.getMonth() < birthDate.getMonth() || (currentDate.getMonth() === birthDate.getMonth() && currentDate.getDate() < birthDate.getDate())) {
        age--;
    }
    let formattedDate = `${day < 10 ? '0' : ''}${day}. ${month < 10 ? '0' : ''}${month}. ${year} | Age: ${age}`;
    let playerBirthDate = createP(formattedDate);
    playerBirthDate.parent(playerInfo);
    playerBirthDate.style("font-family", "Poppins-Regular");
    playerBirthDate.style("font-size", "12px");  // Adjust font size
    playerBirthDate.style("margin", "0");
    playerBirthDate.style("color", `#${colors.number}`); 

    // Display player rating with background color
    let playerRating = createP(`${player.statistics.rating}`);
    playerRating.parent(playerInfo);
    playerRating.style("font-family", "Poppins-Regular");
    playerRating.style("font-size", "12px");  // Adjust font size
    playerRating.style("margin", "0");
    playerRating.style("margin-top", "10px");
    playerRating.style("color", `#${colors.primary}`); // Set text color to white
    playerRating.style("background-color", `#${colors.number}`);
    playerRating.style('border-radius', '5px'); // Adjust border-radius for a rounded appearance
    playerRating.style('padding', '5px'); // Add padding for space
    playerRating.style("width", "min-content");


    let playerId = `player_${player.player.id}`;
    playerCard.id(playerId);
    let primarycolor = colors.primary;

    // Add more information as needed
    playerCard.mouseOver(() => {
        playerCard.style('cursor', 'pointer');
        playerCard.style('background-color', `rgba(${hexToRgb(colors.primary)}, 1)`);  // Set opacity to 100%
    });

    // Add a mouseOut event listener to reset cursor and background opacity
    playerCard.mouseOut(() => {
        playerCard.style('cursor', 'auto');  // Reset cursor to default
        playerCard.style('background-color', `rgba(${hexToRgb(colors.primary)}, 0.8)`);  // Reset opacity
    });

    // Add a click event listener to the player card
    playerCard.mousePressed(() => {
        // Call your new function here, passing the player data if needed
        playerCardClicked(player, primarycolor);
    });

    return playerCard;
});

// Track the state of heatmap visibility
// Track the state of heatmap visibility
let heatmapVisible = false;
let lastClickedPlayer = null;

function playerCardClicked(player, color) {
    if (player.heatmap) {
        // Clear the canvas and reset player card background color if another player was clicked
        if (lastClickedPlayer && lastClickedPlayer !== player) {
            clearCanvas();
        }

        // Toggle heatmap visibility
        heatmapVisible = !heatmapVisible;

        if (heatmapVisible) {
            fill(color);
            selectedPlayer = {player, color};
            // Your logic for handling the player card click when heatmap is available goes here
            console.log('Player card clicked:', player);
            drawPlayerHeatmap(player.heatmap, color, player.player.name);
            //select(`#player_${player.player.id}`).style('background-color', `rgba(${hexToRgb(color)}, 1)`);
            lastClickedPlayer = player;
        } else {
            // Clear the canvas and reset player card background color
            selectedPlayer = null;
            clearCanvas();
            //select(`#player_${player.player.id}`).style('background-color', `rgba(${hexToRgb(color)}, 0.8)`);
            lastClickedPlayer = null;
        }
    } else {
        // Change background color to indicate heatmap is not available
        select(`#player_${player.player.id}`).style('background-color', 'rgba(255, 0, 0, 0.8)');

        // Reset background color after a short delay (e.g., 500 milliseconds)
        setTimeout(() => {
            select(`#player_${player.player.id}`).style('background-color', `rgba(${hexToRgb(color)}, 0.8)`);
        }, 500);
    }
}

function clearCanvas() {
    clear();
    background(bgImage)
    image(fieldImage, fieldX, fieldY, fieldWidth, fieldHeight);
}




// Function to convert hex color to RGB format
function hexToRgb(hex) {
    // Remove the hash
    hex = hex.replace(/^#/, '');

    // Parse the values
    var bigint = parseInt(hex, 16);

    // Extract the RGB values
    var r = (bigint >> 16) & 255;
    var g = (bigint >> 8) & 255;
    var b = bigint & 255;

    // Return the RGB values as a string
    return `${r}, ${g}, ${b}`;
}



function createTeamData() {
    // Clear existing team data containers
    let teamDataContainer = createDiv("");
    teamDataContainer.style("display", "flex"); // Use flexbox for layout
    teamDataContainer.style("width", `calc(100% - 20px)`); // Span the whole windowWidth with 10px padding on the left and right
    teamDataContainer.style("padding", "10px"); // Add padding
    teamDataContainer.style("position", "fixed"); // Fixed position
    teamDataContainer.style("top", "50%"); // Center vertically
    teamDataContainer.position(0, windowHeight / 2 - fieldHeight / 2 - 38);
    teamDataContainer.style("transform", "translateY(-50%)"); // Center vertically
    teamDataContainer.style("background-color", "rgba(0, 0, 0, 0.5)"); // Transparent background color
    teamDataContainer.style("color", "rgba(255, 255, 255, 1)");
    teamDataContainer.style("overflow-y", "auto"); // Enable vertical scrolling if it overflows

    // Create a div element for home team data
    let homeDataContainer = createDiv("");
    homeDataContainer.id("home");
    homeDataContainer.style("flex", "1"); // Use flex to divide the space equally
    homeDataContainer.style("text-align", "center");
    homeDataContainer.parent(teamDataContainer); // Parent it to the team data container

    // Create and add content for home team data
    let homeTeamName = createP("Home");
    homeTeamName.parent(homeDataContainer);
    homeTeamName.style("font-family", "Poppins-Regular");

    // Create a div element for away team data
    let awayDataContainer = createDiv("");
    awayDataContainer.id("away");
    awayDataContainer.style("flex", "1"); // Use flex to divide the space equally
    awayDataContainer.style("text-align", "center");
    awayDataContainer.parent(teamDataContainer); // Parent it to the team data container

    // Create and add content for away team data
    let awayTeamName = createP("Away");
    awayTeamName.parent(awayDataContainer);
    awayTeamName.style("font-family", "Poppins-Regular");
}


function checkboxChanged() {
    let variableName = this.elt.innerText.trim(); // Trim extra spaces
    variableSettings[variableName] = this.checked();
    createVisualizationTab();
}


// Rest of your code, including drawTeamHeatmap, should remain unchanged

function drawTeamHeatmap(team, minute) {
	fill(getColor(team.playerColor.primary));
	for (let player of team.players) {
		if (player.heatmap) {
			drawPlayerHeatmap(player.heatmap, null, null, minute);
		}
	}
}

function drawPlayerHeatmap(heatmap, clr, player_name) {
    if (clr) {
        fill(getColor(clr))
    }
    for (let i = 0; i < heatmap.length; i++) {
        let coords = heatmap[i];
    
        if (i > sldValue) {
            break; // This will exit the loop
        }
    
        let mappedX = map(coords.x, x0, x1, fieldX, fieldX + fieldWidth);
        let mappedY = map(coords.y, y0, y1, fieldY + fieldHeight, fieldY);
        ellipse(mappedX, mappedY, fieldWidth / 25, fieldWidth / 25);
    }

    if(player_name) {
        textFont('Poppins-Regular');
        textAlign(CENTER, CENTER);
        fill(getColor(clr)); // Set text color to white
        textSize(24); // Increase font size
        text(player_name, width / 2, height / 2 - fieldHeight / 2 + 30); // Centered text on the canvas
    }
}

function getColor(hexCode) {
	let hexColor = color(`#${hexCode}`); // Red color
	hexColor.setAlpha(80);
	noStroke();
	return hexColor;
}
