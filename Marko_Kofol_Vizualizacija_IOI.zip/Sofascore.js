class Sofascore {
  constructor(apiKey, canvas) {
    this.apiKey = apiKey;
    this.canvas = canvas;
    this.init();
  }
  
  draw(){}
  
  init() {
    this.matchId = 9644933;
    this.homeTeam = null;
    this.awayTeam = null;
    this.playerNum = 0;
    
    this.interval = 60; // Number of frames to delay
    this.counter = 0; // Counter to keep track of frames
    this.isLoading = false;
    
    this.loadingBar = new LoadingBar(this.canvas, 0, 22);
  }
  
  fetchMatches(teamId) {
    this.fetchLatestMatches(teamId, (matches) => {
      this.matchId = matches.events[0].id;
      this.matchId = 9644933;
    });
  }
 
  saveMatchData() {
    console.log('Saving data for: ' + this.matchId);
    if (!this.matchId) {
      return;
    }
    this.isLoading = true;
    
    this.fetchLineups(this.matchId, (home, away) => {
      this.homeTeam = home;
      this.awayTeam = away;
      
      this.loadingBar.draw(this.playerNum);
      
      let fetchInterval = setInterval(() => {
        console.log('Saving data for player ' + this.playerNum);
        if (this.playerNum < this.homeTeam.players.length) {
          this.fetchPlayerHeatmaps(this.matchId, this.homeTeam.players[this.playerNum].player.id, (heatmap) => {
            this.homeTeam.players[this.playerNum].heatmap = heatmap;
          });
        }
      
        if (this.playerNum < this.awayTeam.players.length) {
          this.fetchPlayerHeatmaps(this.matchId, this.awayTeam.players[this.playerNum].player.id, (heatmap) => {
            this.awayTeam.players[this.playerNum].heatmap = heatmap;
          });
        }
        
        this.playerNum++;
        this.loadingBar.draw(this.playerNum);
        
        if (this.playerNum >= this.homeTeam.players.length && this.playerNum >= this.awayTeam.players.length) {
          const data = {
            homeTeam: this.homeTeam,
            awayTeam: this.awayTeam
          };
          saveJSONObject(data, 'matchData.json');
          this.isLoading = false;
          clearInterval(fetchInterval);
        }
      }, 1000);
    });
  }
  
  /* API CALLS */
  fetchLatestMatches(teamId, callback) {
    const options = {
      method: 'GET',
      url: 'https://sofascore.p.rapidapi.com/teams/get-last-matches',
      params: {
        teamId: teamId,
        pageIndex: '0'
      },
      headers: {
        'X-RapidAPI-Key': apiKey,
        'X-RapidAPI-Host': 'sofascore.p.rapidapi.com'
      }
    };
  
    axios
      .request(options)
      .then((response) => {
        const matches = response.data;
        callback(matches);
      })
      .catch((error) => {
        console.error(error);
      });
  }
  
  fetchLineups(matchId, callback) {
   const options = {
      method: 'GET',
      url: 'https://sofascore.p.rapidapi.com/matches/get-lineups',
      params: {matchId: matchId},
      headers: {
        'X-RapidAPI-Key': apiKey,
        'X-RapidAPI-Host': 'sofascore.p.rapidapi.com'
      }
    }
    
    
    axios
      .request(options)
      .then((response) => {
        const home = response.data.home;
        const away = response.data.away
        callback(home, away);
      })
      .catch((error) => {
        console.error(error);
      });
  }
  
  fetchPlayerHeatmaps(matchId, playerId, callback) {
    const options = {
      method: 'GET',
      url: 'https://sofascore.p.rapidapi.com/matches/get-player-heatmap',
      params: {
        matchId: matchId,
        playerId: playerId
      },
      headers: {
        'X-RapidAPI-Key': apiKey,
        'X-RapidAPI-Host': 'sofascore.p.rapidapi.com'
      }
    };
    
  
    axios
      .request(options)
      .then((response) => {
        const playerHeatmap = response.data.heatmap;
        callback(playerHeatmap);
      })
      .catch((error) => {
        console.error(error);
      });
  }
}
