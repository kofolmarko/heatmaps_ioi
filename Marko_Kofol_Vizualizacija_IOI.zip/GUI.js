const createHeader = (() => {
    let headerContainer = createDiv("");
    headerContainer.style("display", "flex");
    headerContainer.style("justify-content", "space-between");
    headerContainer.style("align-items", "center");
    headerContainer.style("width", "100%");
    headerContainer.style("background-color", "rgba(0, 0, 0, 0.5)");
    headerContainer.style("position", "absolute");
    headerContainer.style("top", "0");
    headerContainer.style("left", "0");
    headerContainer.style("border-radius", "0 0 10px 10px");
    headerContainer.style("box-shadow", "0 -4px 6px rgba(0, 0, 0, 0.1)");

    let titleContainer = createDiv("Player heatmaps during a selected football game");
    titleContainer.style("color", "white");
    titleContainer.style("font-size", "24px");
    titleContainer.style("font-family", "Poppins-Regular");
    titleContainer.style("padding", "10px");
    titleContainer.parent(headerContainer);

    let buttonContainer = createDiv("");
    buttonContainer.style("display", "flex");
    buttonContainer.style("gap", "10px");
    buttonContainer.parent(headerContainer);

    createHeaderButton({
        name: "Visualization",
        action: createVisualizationTab,
        parent: buttonContainer
    });

    createHeaderButton({
        name: 'API',
        action: createApiTab,
        parent: buttonContainer
    });
});

const createHeaderButton = ((btn) => {
    let button = createDiv(btn.name);
    button.style("flex", "1");
    button.style("cursor", "pointer");
    button.style("text-align", "center");
    button.style("background-color", "rgba(245, 148, 12, 0.8)");
    button.style("color", "black");
    button.style("padding", "10px 20px");
    button.style("margin", "10px");
    button.style("border-radius", "5px");
    button.style("font-family", "Poppins-Regular");
    button.mousePressed(btn.action);
    button.parent(btn.parent);
    button.mouseOver(() => {
        button.style("background-color", "rgba(245, 148, 12, 1)");
    });
    button.mouseOut(() => {
        button.style("background-color", "rgba(245, 148, 12, 0.8)");
    });
    return button;
});

function createApiTab() {
    removeElements();
    createHeader();

    let cnv = createCanvas(windowWidth, windowHeight);
    let cnvX = windowWidth / 2 - cnv.width / 2;
    let cnvY = windowHeight / 2 - cnv.height / 2;
    cnv.position(cnvX, cnvY);
	background("#fae");

	const apiKeyInput = createInput(apiKey);
	apiKeyInput.position(windowWidth / 2 - apiKeyInput.size().width / 2 + cnvX, cnvY + 225);
	let apiKeyLabel = "Api Key";
	text(apiKeyLabel, windowWidth / 2 - textWidth(apiKeyLabel) / 2, 220);

	const teamIdInput = createInput(teamId);
	let teamIdLabel = "Team ID";
	teamIdInput.position(windowWidth / 2 - teamIdInput.size().width / 2 + cnvX, cnvY + 285);
	text(teamIdLabel, windowWidth / 2 - textWidth(teamIdLabel) / 2, 280);

	sofascore = new Sofascore(apiKey, this); // Remove 'let' to use sofascore globally

	const fetchBtn = createButton("Fetch Data");
	fetchBtn.position(windowWidth / 2 - fetchBtn.size().width / 2 + cnvX, cnvY + 320);
	fetchBtn.mousePressed(() => sofascore.saveMatchData());

    let disclaimer = 
    `      In order to fetch data, get an API key from the site https://rapidapi.com/hub
   Find a match you would like to see and find its ID (can be found on the API site).
        Enter the ID and API key and download data from the selected match.
Place the downloaded .json file in the main directory of this project and rename it to matchData.`;
    text(disclaimer, windowWidth / 2 - 500 / 2, 380);
    const rapidApiBtn = createButton("RapidAPI");
	rapidApiBtn.position(windowWidth / 2 - rapidApiBtn.size().width / 2 + cnvX, cnvY + 430);
	rapidApiBtn.mousePressed(() => window.open("https://rapidapi.com/hub", "_blank"));
}

function createVisualizationTab() {
	removeElements();

	const aspectRatio = fieldImage.width / fieldImage.height;
	fieldWidth = windowWidth * 0.6;
	fieldHeight = fieldWidth / aspectRatio;

	if (fieldHeight > windowHeight * 0.6) {
		fieldHeight = windowHeight * 0.6;
		fieldWidth = fieldHeight * aspectRatio;
	}

	let cnv = createCanvas(windowWidth, windowHeight);
    cnv.position(0, 0);
	background(bgImage);

	fieldX = (windowWidth - fieldWidth) / 2;
	fieldY = (windowHeight - fieldHeight) / 2;

	image(fieldImage, fieldX, fieldY, fieldWidth, fieldHeight);
    createHeader();
	createGUI(variableSettings);
    createSorting();
    createTeamData();

    if (selectedPlayer) {
        drawPlayerHeatmap(selectedPlayer.player.heatmap, selectedPlayer.color,  selectedPlayer.player.player.name);
    }

	/* FOR INFORMATION */
    console.log(matchData);

	if (variableSettings.Home_Heatmap) {
		drawTeamHeatmap(matchData.homeTeam);
	}
	if (variableSettings.Away_Heatmap) {
		drawTeamHeatmap(matchData.awayTeam);
	}
}

const createSorting = (() => {
    // Create the sorting dropdown
     // Append the dropdown to the sorting container
});

function sliderChanged() {
    if (variableSettings.Home_Heatmap) {
        createVisualizationTab()
    }
    if (variableSettings.Away_Heatmap) {
        createVisualizationTab()
    }
    if (selectedPlayer) {
        createVisualizationTab()
    }
    // Add logic to handle slider value change as needed
}
let sldValue = 100;
function createGUI(settings) {
    // Create a rectangle under the field image
    let rectangleUnderField = createDiv("");
    rectangleUnderField.style("width", `${fieldWidth}px`);
    rectangleUnderField.style("height", "70px");
    rectangleUnderField.style("border-radius", "0 0 5px 10px");
    rectangleUnderField.style("background-color", "rgba(0, 0, 0, 0.5)"); // Adjust color and transparency as needed
    rectangleUnderField.position(fieldX, fieldY + fieldHeight);
    rectangleUnderField.style("display", "flex");
    rectangleUnderField.style("align-items", "center"); // Center items vertically

    rectangleUnderField.html('');

    let sliderStyle = `
        width: 100px;
        margin-left: 10px;
    `;

    let minuteText = createP('Minute: ' + sldValue);
    minuteText.style("font-family", "Poppins-Regular");
    minuteText.style("color", "white");
    minuteText.parent(rectangleUnderField);

    let customSlider = createSlider(0, 100, sldValue, 1);
    customSlider.style(sliderStyle);
    customSlider.parent(rectangleUnderField);
    customSlider.changed(() => {
        sliderChanged();
        sldValue = customSlider.value();
        minuteText.html('Minute: ' + sldValue);
         // Call your sliderChanged function here if needed
    });


    // Styling for checkboxes
    let checkboxStyle = `
        font-family: "Poppins-Regular";
        color: white;
        margin-right: 10px;
    `;

    for (let variable in settings) {
        let checkbox = createCheckbox(variable, settings[variable]);
        checkbox.parent(rectangleUnderField);
        checkbox.changed(checkboxChanged);
        checkbox.style(checkboxStyle);
    }

    // Styling for sorting dropdown
    let selectStyle = `
        font-family: "Poppins-Regular";
        color: white;
        background-color: transparent;
        border: 1px solid white;
        border-radius: 5px;
        margin-left: 10px;
    `;

    let sortSelector = createSelect();
    sortSelector.style(selectStyle);
    sortSelector.option('Rating (Low to High)', 'ratingAsc');
    sortSelector.option('Rating (High to Low)', 'ratingDesc');
    sortSelector.parent(rectangleUnderField);

    // Attach event listener to the dropdown
    sortSelector.changed(() => {
        let selectedOption = sortSelector.value();
        let container = select('#home');
        container.html('');
        let container2 = select("#away");
        container2.html('');
        createPlayerSegment('home', selectedOption);
        createPlayerSegment('away', selectedOption);
    });

    // Initial rendering
    createPlayerSegment('home', sortSelector.value());
    createPlayerSegment('away', sortSelector.value());
}

function camelCaseToReadable(input) {
    return input.replace(/([a-z])([A-Z])/g, '$1 $2').replace(/^./, function(str){ return str.toUpperCase(); });
}