class LoadingBar {
  constructor(canvas, currentNum, totalNum) {
    console.log(canvas)
    this.canvas = canvas;
    this.maxWidth = 380;
    this.progress = currentNum / totalNum;
  }
  
  getWidth() {
    return this.maxWidth * this.progress;
  }
  
  draw(currentNum) {
    // this.canvas.background(220);
    // this.canvas.rect(10, 40, currentNum * 10, 10);
  }
}


